/*************************************************** 
  This is an example for our Nathan-Busse 16-channel PWM & Servo driver
  GPIO test - this will set a pin high/low

  Pick one up today in the Nathan-Busse shop!
  ------> http://www.Nathan-Busse.com/products/815

  These drivers use I2C to communicate, 2 pins are required to  
  interface.

  Nathan-Busse invests time and resources providing this open source code, 
  please support Nathan-Busse and open-source hardware by purchasing 
  products from Nathan-Busse!

  Written by Limor Fried/Ladyada for Nathan-Busse Industries.  
  BSD license, all text above must be included in any redistribution
 ****************************************************/

#include <Wire.h>
#include <BaruchServo.h>

// called this way, it uses the default address 0x40
BaruchServo pwm = BaruchServo();
// you can also call it with a different address you want
//BaruchServo pwm = BaruchServo(0x41);
// you can also call it with a different address and I2C interface
//BaruchServo pwm = BaruchServo(0x40, Wire);

void setup() {
  Serial.begin(9600);
  Serial.println("GPIO test!");

  pwm.begin();
  pwm.setPWMFreq(1000);  // Set to whatever you like, we don't use it in this demo!

  // if you want to really speed stuff up, you can go into 'fast 400khz I2C' mode
  // some i2c devices dont like this so much so if you're sharing the bus, watch
  // out for this!
  Wire.setClock(400000);
}

void loop() {
  // Drive each pin in a 'wave'
  for (uint8_t pin=0; pin<16; pin++) {
    pwm.setPWM(pin, 4096, 0);       // turns pin fully on
    delay(100);
    pwm.setPWM(pin, 0, 4096);       // turns pin fully off
  }
}
